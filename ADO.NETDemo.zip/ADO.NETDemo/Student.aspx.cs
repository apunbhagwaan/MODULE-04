﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace ADO.NETDemo
{
    public partial class Student : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Training"].ConnectionString);
        SqlCommand cmd = null;
        SqlDataReader dr = null;

        protected void Page_Load(object sender, EventArgs e)
        {
            if(!Page.IsPostBack)
                PopulateStudent();

        }

        public void PopulateStudent()
        {
            cmd = new SqlCommand("SELECT * FROM Student_Master", con);
            con.Open();
            dr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            if (dr.HasRows)
                dt.Load(dr);
            con.Close();

            gvStudent.DataSource = dt;
            gvStudent.DataBind(); //must bind the data in ado.net
        }

        protected void btnInsert_Click(object sender, EventArgs e)
        { 
cmd = new SqlCommand("Insert into Student_Master(Stud_Code,Stud_name,Dept_Code,Stud_dob,Address) values (@SCode, @SName,@SDept,@SDOB,@Address)", con);
        cmd.Parameters.AddWithValue("@SCode", txtCode.Text);
            cmd.Parameters.AddWithValue("@SName", txtSName.Text);
            cmd.Parameters.AddWithValue("@SDept", txtDName.Text);
            cmd.Parameters.AddWithValue("@SDOB",Convert.ToDateTime(txtDOB.Text));
            cmd.Parameters.AddWithValue("@Address", txtAdd.Text);

            con.Open();

            int recordsAffected = cmd.ExecuteNonQuery();

        con.Close();
           
            if(recordsAffected>0)
            {
                Response.Write("<script type='text/javascript'>alert('Student Record inserted successfully');</script>");
                PopulateStudent();
    }

            else
                Response.Write("<script type='text/javascript'>alert('Student Record NOT inserted');</script>"); 
 

        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            cmd = new SqlCommand("Update Student_Master set Stud_name=@SName,Dept_Code=@SDept,Stud_dob=@SDOB,Address=@Address where Stud_Code=@SCode", con);
            cmd.Parameters.AddWithValue("@SCode", txtCode.Text);
            cmd.Parameters.AddWithValue("@SName", txtSName.Text);
            cmd.Parameters.AddWithValue("@SDept", txtDName.Text);
            cmd.Parameters.AddWithValue("@SDOB", txtDOB.Text);
            cmd.Parameters.AddWithValue("@Address", txtAdd.Text);
            con.Open();
            int recordsAffected = cmd.ExecuteNonQuery();
            con.Close();

            if (recordsAffected > 0)
            {
                Response.Write("<script type='text/javascript'>alert('Student Record updated successfully');</script>");
                PopulateStudent();
            }
            else
                Response.Write("<script type='text/javascript'>alert('Student Record NOT updated');</script>");

        }

        protected void btnDelete_Click(object sender, EventArgs e)
        {
            cmd = new SqlCommand("Delete from Student_Master where Stud_Code=@SCode",con);
            cmd.Parameters.AddWithValue("@SCode", txtCode.Text);
            con.Open();
            int recordsAffected = cmd.ExecuteNonQuery();
            con.Close();
            if (recordsAffected > 0)
            {
                Response.Write("<script type='text/javascript'>alert('Student Record deleted successfully');</script>");
                PopulateStudent();
            }
            else
                Response.Write("<script type='text/javascript'>alert('Student Record NOT deleted');</script>");


        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            //List<Student> stuList = new List<Student>();
            //cmd = new SqlCommand("select * from Student_Master where Stud_Code=@SCode", con);
            //con.Open();
            //dr = cmd.ExecuteReader();
            //con.Close();
            //if (dr.HasRows)
            //{
            //    while (dr.Read())
            //    {
            //        Student stud = new Student();


            //        stud.txtCode.Text = dr[0].ToString();
            //        stud.txtSName.Text = dr[1].ToString();
            //        stud.txtDName.Text = dr[2].ToString();
            //        stud.txtDOB.Text = dr[3].ToString();
            //        stud.txtAdd.Text = dr[4].ToString();
            //        stuList.Add(stud);
            //    }
            //}
            //dr.Close();

            
                cmd = new SqlCommand("select * from Student_Master where Stud_Code=@scode", con);
                cmd.Parameters.AddWithValue("@scode", txtCode.Text);

                if (con.State == System.Data.ConnectionState.Closed)
                    con.Open();

                dr = cmd.ExecuteReader();
                DataTable dt = new DataTable();
                if (dr.HasRows)
                {
                    dt.Load(dr);
                }

                if (con.State == System.Data.ConnectionState.Open)
                    con.Close();
            gvStudent.DataSource = dt;
            gvStudent.DataBind();
            }

        protected void btnClear_Click(object sender, EventArgs e)
        {
            txtSName.Text = string.Empty;
            txtCode.Text = string.Empty;
            txtDName.Text = string.Empty;
            txtDOB.Text = string.Empty;
            txtAdd.Text = string.Empty;


        }

        protected void NumberOfStudent_Click(object sender, EventArgs e)
        {
            cmd = new SqlCommand("select count(*) as Total from Student_Master", con);
            

            if (con.State == System.Data.ConnectionState.Closed)
                con.Open();

            dr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            if (dr.HasRows)
            {
                dt.Load(dr);
            }

            if (con.State == System.Data.ConnectionState.Open)
                con.Close();
            gvStudent.DataSource = dt;
            gvStudent.DataBind();
        }
    }
    }

