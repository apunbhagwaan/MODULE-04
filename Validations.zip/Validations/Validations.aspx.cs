﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Validations
{
    public partial class Validations : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // this.UnobtrusiveValidationMode = System.Web.UI.UnobtrusiveValidationMode;


            if (Page.IsPostBack == false)
            {
                /*if page.ispostback is not written it will add same 
                list to the drop down as Page_load is called multiple times.
                
                 to check if the page loaded previously or not*/

                ddlCity.Items.Add("Mumbai");
                ddlCity.Items.Add("Pune");
                ddlCity.Items.Add("Chennai");
                ddlCity.Items.Add("Banglore");
                ddlCity.Items.Add("Noida");
                ddlCity.Items.Add("Hyderabad");
            }
        }

           
           
    }
}