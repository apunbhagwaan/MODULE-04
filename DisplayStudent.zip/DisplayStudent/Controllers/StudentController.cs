﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DisplayStudent.Models;

namespace DisplayStudent.Controllers
{
    public class StudentController : Controller
    {

        Training_24Oct18_PuneEntities context = new Training_24Oct18_PuneEntities();
        

        // GET: Student
        public ActionResult Index()
        {
            var query = context.Student_master.Where(s => s.Address == "mumbai");
            ViewBag.StudList = query.ToList();

            return View();
        }

        public ActionResult Index2()
        {
            var query = context.Student_master.Where(s => s.Address == null);
            ViewBag.StudList = query.ToList();

            return View();
        }



        public ActionResult Index3()
        {
            var query = context.Student_master.Where(s => s.Address == "pune" || s.Dept_Code==10);
            ViewBag.StudList = query.ToList();

            return View();
        }



        public ActionResult Index4()
        {
            var query = context.Student_master.Where(s => s.Address == "pune" & s.Stud_Dob.Value.Year == 1995);
            ViewBag.StudList = query.ToList();

            return View();
        }


        public ActionResult Index5()
        {
            var query = context.Student_master.Where(s => s.Stud_Dob.Value.Year>=1989 & s.Stud_Dob.Value.Year <= 1996);
            ViewBag.StudList = query.ToList();

            return View();
        }



        public ActionResult Index6()
        {
            var query = context.Student_master.Where(s => s.Stud_Dob.Value >=  new DateTime(1991,6,1) & s.Stud_Dob.Value <= new DateTime( 1994,7,1));// or this will also do Convert.ToDateTime("06/01/01")  
            ViewBag.StudList = query.ToList();

            return View();
        }







    }
}