﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Module_Details
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Training_24Oct18_PuneEntities dbContext = null;
        List<Trainee_Info> trainee;     //create list object

        public MainWindow()
        {
            InitializeComponent();
            dbContext = new Training_24Oct18_PuneEntities();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            PopulateUI();
        }

        public void PopulateUI()
        {
            trainee = dbContext.Trainee_Info.ToList();

            var res = from t in trainee where t.BatchName.Equals(".net") select t; //It will search only for the row which contains the .Net batch data from the db trainee_Info
            gridD.ItemsSource = res;
        }
         
        private void Btn_Click(object sender, RoutedEventArgs e) //to insert data
        {
            Trainee_Info trainee = new Trainee_Info();
            trainee.ModName = txtMN.Text;
            trainee.BatchName = cmbBN.Text;
            trainee.Comments = TxtC.Text;

            dbContext.Trainee_Info.Add(trainee);
            dbContext.SaveChanges();
            MessageBox.Show("Data Inserted");
            PopulateUI();
        }

        private void Btn2_Click(object sender, RoutedEventArgs e) //to show data of .Net batch 
        {
           PopulateUI();
        }
    }
}
