﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Trainee.Exceptions
{
    [Serializable]
    public class TraineeExcp : Exception
    {
        public TraineeExcp()
        {

        }

        public TraineeExcp(string message) : base(message)
        {
        }

        public TraineeExcp(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected TraineeExcp(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}
    
