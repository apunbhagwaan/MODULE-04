﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Trainee.Entity;
using Trainee.Exceptions;
using System.Configuration;

namespace Trainee.DAL
{
    public class TraineeDal
    {
        // For Sql Database Link operations
        SqlConnection cn = null;
        SqlCommand cmd = null;
        SqlDataReader dr = null;

        public TraineeDal()
        {
            cn = new SqlConnection(ConfigurationManager.ConnectionStrings["cn1"].ConnectionString);
        }

        public bool InsertDAL(Traineent traineent)
        {
            bool traineeAdded = false;
            try
            {
                //cmd = new SqlCommand("insert into [sahana326].[Trainee_Info] values(@mName, @bName, @comments)", cn);
                
                cmd = new SqlCommand("sahana326.USP_Add", cn); //for stored procedure
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@pName", traineent.ModName);
                cmd.Parameters.AddWithValue("@price", traineent.BatchName);
                cmd.Parameters.AddWithValue("@exDate", traineent.Comments);

                cn.Open();
                int row = cmd.ExecuteNonQuery();
                if (row > 0)
                    traineeAdded = true;
            }

            catch (TraineeExcp ex2)
            {
               
                throw ex2;
            }
            catch (Exception ex1)
            {

                throw ex1;
            }

            finally
            {
                if (cn.State == System.Data.ConnectionState.Open)
                {
                    cn.Close();
                }
            }
            return traineeAdded;
        }
            

            public List<Traineent> SelectAll()
            {
                List<Traineent> TraineeList = new List<Traineent>();
                try
                {
                    cmd = new SqlCommand(" select * from [sahana326].[Trainee_Info] ", cn); //Fetch List from the database connection.
                    cn.Open();
                    dr = cmd.ExecuteReader();
                    if (dr.HasRows)
                    {
                        while (dr.Read())
                        {
                            Traineent t = new Traineent();
                            t.Id = Convert.ToInt32(dr[0]);
                            t.ModName = dr[1].ToString();
                            t.BatchName = dr[2].ToString();
                            t.Comments = dr[3].ToString();
                        TraineeList.Add(t);
                        }
                    }
                    dr.Close();
                }
                catch (Exception ex1)
                {

                    throw ex1;
                }
                finally
                {
                    if (cn.State == System.Data.ConnectionState.Open)
                    {
                        cn.Close();
                    }
                }

                return TraineeList;
            }
        
    }
}
