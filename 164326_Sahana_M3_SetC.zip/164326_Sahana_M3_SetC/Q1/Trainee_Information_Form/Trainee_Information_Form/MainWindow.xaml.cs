﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Trainee.Entity;
using Trainee.Exceptions;
using Trainee.BL;

namespace Trainee_Information_Form
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        Traineent t = null;

        public bool IsInputValid()
        {
            bool isValid = false;
            StringBuilder sb = new StringBuilder();

           
            if (txtMN.Text == null | txtMN.Text == string.Empty | txtMN.Text.Length < 1)
            {
                sb.Append("Module name is Mandatory!");
                isValid = false;
            }
            if (cmbBN.Text == null | cmbBN.Text == string.Empty | cmbBN.Text.Length < 1)
            {
                sb.Append("Batch Name is Mandatory!");
                isValid = false;
            }

            if (!isValid)
            {
                throw new TraineeExcp(sb.ToString());
            }
            return isValid;
        }


        public void PopulateUI()
        {
            List<Traineent> pro = Traineebl.SelectAll();
            gridD.ItemsSource = pro;
            
        }




        private void Btn_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (IsInputValid())
                {

                    Traineent t = new Traineent
                    {
                        ModName = txtMN.Text,
                        BatchName=cmbBN.Text
                    };

                    //Traineebl.InsertBL(t); 
                    MessageBox.Show("Data Inserted");
                    PopulateUI();
                }

            }
            catch (TraineeExcp ex1)
            {
                MessageBox.Show(ex1.Message);
            }
            catch (Exception ex2)
            {
                MessageBox.Show(ex2.Message);
            }

        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            PopulateUI();
        }
    }
}
