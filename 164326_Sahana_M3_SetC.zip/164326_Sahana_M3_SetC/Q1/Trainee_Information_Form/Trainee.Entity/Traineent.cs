﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Trainee.Entity
{
    public class Traineent
    {
        public int Id { get; set; }
        public string ModName { get; set; }
        public String BatchName { get; set; }
        public String Comments { get; set; }
    }
}
