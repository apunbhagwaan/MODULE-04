﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Trainee.DAL;
using Trainee.Entity;
using Trainee.Exceptions;

namespace Trainee.BL
{
    public class Traineebl
    {
        private static bool ValidateProduct(Traineent traineeV)
        {
            StringBuilder sb = new StringBuilder();
            bool ValidTrainee = true;

            if (traineeV.BatchName == string.Empty)
            {
                ValidTrainee = false;
                sb.Append(Environment.NewLine + "Batch Name Required");
            }
            if (traineeV.ModName == string.Empty)
            {
                ValidTrainee = false;
                sb.Append(Environment.NewLine + "Module Name Required");
            }
            if (traineeV.Comments == string.Empty)
            {
                ValidTrainee = false;
                sb.Append(Environment.NewLine + "Comments are Required");
            }
            if (ValidTrainee == false)
            {
                throw new TraineeExcp(sb.ToString());
            }
            return ValidTrainee;
        }

        public static List<Traineent> GetAllTRainee()
        {
            List<Traineent> TraineeList = null;
            try
            {
                TraineeDal objTrainee = new TraineeDal();
                TraineeList = objTrainee.SelectAll();

            }
            catch (TraineeExcp ex1)
            {
                throw ex1;
            }
            catch (Exception ex2)
            {

                throw ex2;
            }
            return TraineeList;
        }

        public static List<Traineent> SelectAll()
        {
            List<Traineent> TraineeList = null;
            try
            {
                TraineeDal objTrainee = new TraineeDal();
                TraineeList = objTrainee.SelectAll();
            }
            catch (TraineeExcp ex1)
            {
                throw ex1;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return TraineeList;

        }

        public bool InsertBL(Traineent traineeV)
        {
            bool traineeInserted = false;
            try
            {
                if (ValidateProduct(traineeV))
                {
                    TraineeDal objTrainee = new TraineeDal();
                    traineeInserted = objTrainee.InsertDAL(traineeV);
                }

            }
            catch (TraineeExcp ex1)
            {
                throw ex1;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return traineeInserted;
        }
    }
}
