﻿create schema sahana326

create table [sahana326].[Trainee_Info]
(
    [Id]      int identity (1, 1) NOT NULL,
    [ModName] varchar   (20) NULL,
    [BatchName]    varchar (18) NULL,
    [Comments]  varchar   (50)      NULL,
    primary key clustered ([Id] asc)
);

insert into [sahana326].[Trainee_Info] ([ModName],[BatchName],[Comments]) values ('M1','Batch1','Good Performance');

select * from  [sahana326].[Trainee_Info] 

 create procedure sahana326.USP_Add
		@mName varchar (20),
		@bName varchar(18),
		@comments varchar(50)
 as 
 insert into [sahana326].[Trainee_Info] values(@mName, @bName, @comments);
