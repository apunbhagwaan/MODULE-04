use Training_24Oct18_Pune

Create table Customer164326
(
customerId int primary key,
customerName varchar(20) not null,
phoneNum int,
emailId varchar(25),
city varchar(10)
)

Create table Orders164326
(
orderId int primary key,
orderDate date not null,
prodName varchar(25),
price int,
quant int,
customerId int unique
)

insert into customer164326(customerId,customerName,phoneNum,emailId,city) values
(101,'Robert',9087654321,'robertgmail.com','Mumbai'),
(102,'Saket Sharma',9087654322,'saket@rediff.com','Pune'),
(103,'Raksha',9087654323,'raksha@gmail.com','Mumbai'),
(104,'Adarsh',9087654324,'adarsh@gmail.com','Mumbai'),
(105,'Kavya',9087654325,'robert@rediff.com','Pune');

insert into orders164326(orderId,orderDate,prodName,price,quant,customerId) values
(1002,'2016/05/05','Memory Card',600,2,102),
(1003,'2016/12/03','Memory Card',450,3,101),
(1004,'2016/05/03','Speaker',1200,2,103),
(1005,'2016/08/03','Memory Card',450,1,105);

drop table orders164326

Create table Customer164326
(
customerId int,
customerName varchar(20) not null,
phoneNum varchar(25),
emailId varchar(25),
city varchar(10)
)

Create table Orders164326
(
orderId int,
orderDate date,
prodName varchar(25),
price int,
quant int,
customerId int
)

select * from Customer164326

select * from Orders16432


--2.1
select Customer164326.customerName from Customer164326 inner join Orders164326 
on(Customer164326.customerId=Orders164326.customerId) where Orders164326.prodName='Memory Card';


--2.6
select orderId,prodName,price,quant,price * quant as total_Billing from Orders164326;


--2.4
create procedure upds_city @city varchar, @customerId int as
 begin
	if exists(select city from customer164326 where city=@city)
	begin
	raiserror('City is not available',12,1,@city);
	end
	else
	begin try
	
	begin
	update customer164326 set city=('Mumbai')
	where @customerId='104';
	end

	end try
	begin catch
	throw
	end catch
 end;
exec upds_city 'mumbai',104;