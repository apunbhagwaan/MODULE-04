﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ViewStateDemo
{
    public partial class Home : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!Page.IsPostBack)
            ViewState["counter"] = 0;
            lblCounter.Text = ViewState["counter"].ToString(); 
        }

        protected void btnShow_Click(object sender, EventArgs e)
        {
            int cnt = (int)ViewState["counter"];
            cnt = cnt + 1;
            ViewState["counter"] = cnt;
            lblCounter.Text= ViewState["counter"].ToString();
        }
    }
}