﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Q3
{
    class Person
    {
        public int Age { get; set; }
        public int Salary { get; set; }
        public string Name { get; set; }

        static void Main()
        {
            // Create an instance of Program.
            Person programInstance = new Person();
            programInstance.Age = 7;
            programInstance.Name = "Sahana";
            programInstance.Salary = 7000;

            // Get type.
            Type type = typeof(Person);

            // Loop over properties.
            foreach (PropertyInfo propertyInfo in type.GetProperties())
            {
                // Get name.
                string name = propertyInfo.Name;

                // Get value on the target instance.
                object value = propertyInfo.GetValue(programInstance, null);

                // Test value type.
                if (value is int)
                {
                    Console.WriteLine("Int: {0} = {1}", name, value);
                }
                else if (value is string)
                {
                    Console.WriteLine("String: {0} = {1}", name, value);
                }
            }
        }
    }
}