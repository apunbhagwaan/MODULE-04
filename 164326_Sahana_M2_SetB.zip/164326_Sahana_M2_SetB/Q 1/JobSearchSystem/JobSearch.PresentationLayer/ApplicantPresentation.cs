﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using JobSearch.Entities;
using JobSearch.BusinessLayer;
using JobSearch.Exceptions;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace JobSearch.PresentationLayer
{
    class ApplicantPresentation
    {
        public static object ApplicantList { get; private set; }

        static void Main(string[] args)
        {
            int choice;
            char ch;
            do
            {
                PrintMenu();
                Console.WriteLine("Enter your Choice:");
                choice = Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        AddApplicant();
                        break;
                    case 2:
                        ListAllApplicants();
                        break;
                    case 3:
                        SearchApplicantByCity();
                        break;
                    default:
                        Console.WriteLine("Invalid Choice");
                        break;
                }
                Console.WriteLine("Enter y to continue or n to exit:");
                ch = Convert.ToChar(Console.ReadLine());
            } while (ch == 'y');
        }

        private static void SearchApplicantByCity()
        {
            City city;
            string SearchApplicantCity;
            Console.WriteLine("Enter City Name of Applicant to search:");
            SearchApplicantCity = Console.ReadLine();
            if (Enum.TryParse<City>(SearchApplicantCity, true, out city))
            {
                List<Applicant> searchApplicant = ApplicantBL.SearchApplicantByCityBL(city);
                if (searchApplicant.Count != 0)
                {


                    Console.WriteLine("******************************************************************************");
                    Console.WriteLine("Applicant Name\t\tPhoneNumber\t\tQualification\t\tDOB\t\tCity");
                    Console.WriteLine("******************************************************************************");
                    foreach (Applicant applicant in searchApplicant)
                    {
                        //Console.WriteLine("{0}\t\t{1}\t\t{2}\t\t{3}\t\t{4}", applicant.ApplicantName,applicant.ApplicantQualification,applicant.ApplicantNumber,applicant.CityName,applicant.ApplicantDOB);
                        Console.WriteLine(applicant.ApplicantName + "\t\t" + applicant.ApplicantNumber + "\t\t" + applicant.ApplicantQualification
                       + "\t" + applicant.ApplicantDOB + "\t" + applicant.CityName);
                    }
                    Console.WriteLine("******************************************************************************");
                }
            }
        }

        private static void ListAllApplicants()
        {
            try
            {
                List<Applicant> applicantList = ApplicantBL.GetAllApplicantsBL(); 
                if (applicantList != null)
                {
                    Console.WriteLine("******************************************************************************");
                    Console.WriteLine("Applicant Name\t\tPhoneNumber\t\tQualification\t\tDOB\t\tCity");
                    Console.WriteLine("******************************************************************************");

                    foreach (Applicant applicant in applicantList)
                    {
                        //Console.WriteLine("{0}\t\t{1}\t\t{2}\t\t{3}\t\t{4}", applicant.ApplicantName, applicant.ApplicantQualification, applicant.ApplicantNumber, applicant.CityName, applicant.ApplicantDOB);
                        Console.WriteLine(applicant.ApplicantName + "\t\t" + applicant.ApplicantNumber + "\t\t" + applicant.ApplicantQualification
                        + "\t" + applicant.ApplicantDOB+ "\t" + applicant.CityName);
                    }
                    Console.WriteLine("******************************************************************************");

                }
                else
                {
                    Console.WriteLine("No Applicant Details Available");
                }
            }

            catch (JobSearchExceptions ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void AddApplicant()
        {
            try
            {
                Applicant newApplicant = new Applicant();

                Console.WriteLine("Enter Applicant Name :");
                newApplicant.ApplicantName = Console.ReadLine();

                Console.WriteLine("Enter PhoneNumber :");
                newApplicant.ApplicantNumber = Console.ReadLine();

                Console.WriteLine("Enter Applicant Qualification:");
                newApplicant.ApplicantName = Console.ReadLine();

                Console.WriteLine("Enter Applicant DOB :");
                newApplicant.ApplicantName = Console.ReadLine();


                Console.WriteLine("Select city of applicant");

                foreach (City city in Enum.GetValues(typeof(City)))
                {
                    string value = city.ToString();
                    Console.WriteLine(value);
                }
                string gueRel = Console.ReadLine();
                newApplicant.CityName = (City)(Enum.Parse(typeof(City), gueRel, true));


                bool applicantAdded = ApplicantBL.AddApplicantBL(newApplicant);
                if (applicantAdded)
                    Console.WriteLine("Applicant Added");
                else
                    Console.WriteLine("Applicant not Added");

                //FileStream fileStream = new FileStream(@"C:\\IO\\13.2.txt", FileMode.Create);
                //BinaryFormatter binaryFormatter = new BinaryFormatter();
                //binaryFormatter.Serialize(fileStream, ApplicantList);
                //fileStream.Close();
                //Console.WriteLine("Suceessful!!!!!!");

            }

            catch (JobSearchExceptions ex)
            {
                Console.WriteLine(ex.Message);
            }

        }

        //private static void DeserializeData()
        //{
        //    try
        //    {
        //        FileStream fileStream = new FileStream(@"C:\\IO\\13.2.txt", FileMode.Open);
        //        BinaryFormatter binaryFormatter = new BinaryFormatter();
        //        List<Applicant> obj = (List<Applicant>)binaryFormatter.Deserialize(fileStream);
        //        fileStream.Close();
        //        foreach (Applicant c in obj)
        //        {
        //            Console.WriteLine("Name" + c.ApplicantName+ "Number:" + c.ApplicantNumber + "Qualification:" + c.ApplicantQualification+ "DOB:" + c.ApplicantDOB+ "City:" + c.CityName);
        //        }



        //    }
        //    catch (UnauthorizedAccessException ex)
        //    {
        //        Console.WriteLine(ex.Message);
        //    }

        //}

        private static void PrintMenu()
        {
            Console.WriteLine("\n***********JOB Applicants***********");
            Console.WriteLine("1. Add Applicant");
            Console.WriteLine("2. List All Applicants");
            Console.WriteLine("3. Search Applicant by City");
            Console.WriteLine("******************************************\n");
            //Console.ReadLine();
        }
    }
}
