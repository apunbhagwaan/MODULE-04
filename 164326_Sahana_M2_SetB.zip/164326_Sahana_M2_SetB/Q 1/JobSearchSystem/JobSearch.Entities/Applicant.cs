﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JobSearch.Entities
{

    public enum City
    {
        
       MUMBAI=1,
       PUNE=2,
       CHENNAI=3,
       BANGALORE=4,   
    }

    public class Applicant
    {
        private string applicantName;

        public string ApplicantName
        {
            get
            {
                return applicantName;
            }

            set
            {
                applicantName = value;
            }
        }

        private string applicantNumber;

        public string ApplicantNumber
        {
            get
            {
                return applicantNumber;
            }
            set
            {
                applicantNumber = value;
            }
        }

        private string applicantQualification;

        public string ApplicantQualification
        {
            get
            {
                return applicantQualification;
            }

            set
            {
                applicantQualification = value;
            }
        }

        private DateTime applicantDob;

        public DateTime ApplicantDOB
        {
            get
            {
                return applicantDob;
            }

            set
            {
                applicantDob = value;
            }
        }

        private City cityName;

        public City CityName
        {
            get
            {
                return cityName;
            }
            set
            {
                cityName = value;
            }
        }



        public Applicant()
        {

            applicantName = string.Empty;
            applicantNumber = string.Empty;
            applicantQualification = string.Empty;
            //applicantDob = DateTime.
            
        }



    }
}
