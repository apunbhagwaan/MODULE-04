﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using JobSearch.DataAccessLayer;
using JobSearch.Entities;
using JobSearch.Exceptions;

namespace JobSearch.BusinessLayer
{
    public class ApplicantBL
    {
        public static List<Applicant> applicantList = new List<Applicant>();
        private static bool ValidateApplicant(Applicant applicant)
        {
            StringBuilder sb = new StringBuilder();
            bool validApplicant = true;

            if(applicant.ApplicantName==String.Empty)
            {
                validApplicant = false;
                sb.Append(Environment.NewLine + "Applicant Name Required");
            }

            if (applicant.ApplicantNumber.Length < 10)
            {
                validApplicant = false;
                sb.Append(Environment.NewLine + "Required 10 Digit Contact Number");
            }

            //if(applicant.ApplicantQualification.Except("BE"))
            //{
            //    validApplicant = false;
            //    sb.Append(Environment.NewLine + "Qualification has to be BE, ME,MCA only.");
            //}

            //if (applicant.CityName.Except("Mumbai"))
            //{
            //    validApplicant = false;
            //    sb.Append(Environment.NewLine + "Cityn has to be Mumbai, Pune, Chennai only.");
            //}

            if (validApplicant == false)
                throw new JobSearchExceptions(sb.ToString());
            return validApplicant;
        }

        public static bool AddApplicantBL(Applicant newApplicant)
        {
            bool applicantAdded = false;
            try
            {
                if (ValidateApplicant(newApplicant))
                {
                    ApplicantDAL applicantDAL = new ApplicantDAL();
                    applicantAdded= applicantDAL.AddApplicantDAL(newApplicant);
                }
            }
            catch (JobSearchExceptions)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return applicantAdded;
        }

        public static List<Applicant> GetAllApplicantsBL()
        {
            List<Applicant> applicantList = null;
            try
            {
                ApplicantDAL applicantDAL = new ApplicantDAL();
                applicantList = applicantDAL.GetAllApplicantsDAL();
            }
            catch (JobSearchExceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return applicantList;
        }

        public static List<Applicant> SearchApplicantByCityBL(City city)
        {
            List<Applicant> searchApplicant = null;
            try
            {
                ApplicantDAL objApplicantDAL = new ApplicantDAL();
                searchApplicant = objApplicantDAL.SearchApplicantByCityDAL(city);

            }
            catch (JobSearchExceptions ex)
            {

                throw ex;
            }
            catch (Exception ex)
            {

                throw ex;
            }
            return searchApplicant;
        }


    }
}
