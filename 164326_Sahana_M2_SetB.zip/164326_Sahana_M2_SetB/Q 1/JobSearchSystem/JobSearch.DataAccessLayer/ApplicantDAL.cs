﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using JobSearch.Entities;
using JobSearch.Exceptions;


namespace JobSearch.DataAccessLayer
{
    public class ApplicantDAL
    {
        public static List<Applicant> applicantList = new List<Applicant>();

        public bool AddApplicantDAL(Applicant newApplicant)
        {
            bool applicantAdded = false;
            try
            {
                applicantList.Add(newApplicant);
                applicantAdded = true;
            }
            catch (SystemException ex)
            {
                throw new JobSearchExceptions(ex.Message);
            }
            return applicantAdded;
        }

        public List<Applicant> GetAllApplicantsDAL()
        {
            return applicantList;
        }


        public List<Applicant> SearchApplicantByCityDAL(City city)
        {
            List<Applicant> searchApplicant = new List<Applicant>();
            try
            {
                searchApplicant.Add(applicantList.Find(applicant => applicant.CityName == city));
            }
            catch (SystemException ex)
            {
                throw new JobSearchExceptions(ex.Message);
            }
            catch (Exception)
            {

                throw;
            }
            return searchApplicant;
        }

        //private static void DeserializeData()
        //{
        //    try
        //    {
        //        FileStream fileStream = new FileStream(@"C:\\IO\\13.2.txt", FileMode.Open);
        //        BinaryFormatter binaryFormatter = new BinaryFormatter();
        //        List<Applicant> obj = (List<Applicant>)binaryFormatter.Deserialize(fileStream);
        //        fileStream.Close();
        //        foreach (Applicant c in obj)
        //        {
        //            Console.WriteLine("Name" + c.ApplicantName+ "Number:" + c.ApplicantNumber + "Qualification:" + c.ApplicantQualification+ "DOB:" + c.ApplicantDOB+ "City:" + c.CityName);
        //        }
    }
}
