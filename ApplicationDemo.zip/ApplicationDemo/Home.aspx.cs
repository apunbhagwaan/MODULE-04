﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ApplicationDemo
{
    public partial class Home : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            lblSessionID.Text = Session.SessionID;
            lblSessionCnt.Text = Session["counter"].ToString();
            lblAppCnt.Text = Application["counter"].ToString();
        }

        protected void btnShow_Click(object sender, EventArgs e)
        {
            int cnt = (int)Session["counter"];
            cnt = cnt + 1;
            Session["counter"] = cnt;
            lblSessionCnt.Text = Session["counter"].ToString();

            int cont = (int)Application["counter"];
            cont = cont + 1;
            Application["counter"] = cont;
            lblAppCnt.Text = Application["counter"].ToString();
        }
    }
}